import numpy as np
from Tools.scripts.dutree import display
from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.metrics import accuracy_score
from sklearn.svm import LinearSVC
from sklearn.pipeline import Pipeline
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_validate
from sklearn.model_selection import GridSearchCV
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.naive_bayes import MultinomialNB
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import GradientBoostingClassifier



categories = ['alt.atheism',
 'comp.graphics',
 'comp.os.ms-windows.misc',
 'comp.sys.ibm.pc.hardware',
 'comp.sys.mac.hardware',
 'comp.windows.x',
 'misc.forsale',
 'rec.autos',
 'rec.motorcycles',
 'rec.sport.baseball',
 'rec.sport.hockey',
 'sci.crypt',
 'sci.electronics',
 'sci.med',
 'sci.space',
 'soc.religion.christian',
 'talk.politics.guns',
 'talk.politics.mideast',
 'talk.politics.misc',
 'talk.religion.misc']

# Get training data from the 20 news group dataset
twenty_train = fetch_20newsgroups(subset='train', shuffle=True, random_state=42, categories = categories,
                                  remove=(['headers', 'footers', 'quotes']))

# plot dataset
# Feature distribution plot
plt.figure(1)
plt.hist(twenty_train.target, rwidth=.2, bins=21, range=(-.5, 20.5))
plt.xlabel("Features", fontsize=40)
plt.ylabel("Count", fontsize=40)
plt.title("Feature distribution in the 20 news-group dataset", fontsize=40)
plt.xticks(range(20), twenty_train.target_names)
plt.xticks(rotation=30)
plt.show()

# Preprocessing method:
pre_method = input("Preprocessing method (1) tf-idf; (2) tf:    ")

# Tokenize text by indexing each word in each document and associate it with its occurrence
count_vect = CountVectorizer()
X_train_counts = count_vect.fit_transform(twenty_train.data)
X_train = 0

# test set
twenty_test = fetch_20newsgroups(subset='test', shuffle=True, random_state=42, categories = categories)
docs_test = twenty_test.data
print("Analyzing 20 News Groups dataset .......................................................")
# fit data with different models using pipelines and forloop

# Use either tf or tf-idf
if pre_method == '2':
    pipeline = Pipeline([
    ('vect', CountVectorizer()),
    ('tfidf', TfidfTransformer(use_idf = False)),
    ('clf', LogisticRegression())  # step2 - classifier
    ])
else:
    pipeline = Pipeline([
    ('vect', CountVectorizer()),
    ('tfidf', TfidfTransformer()),
    ('clf', LogisticRegression())  # step2 - classifier
    ])

    
# Classifiers
clfs = []

clfs.append(LogisticRegression())  # c
clfs.append(DecisionTreeClassifier())
clfs.append(LinearSVC())  # c
clfs.append(AdaBoostClassifier())  # learning rate
clfs.append(RandomForestClassifier())  # n_estimators
clfs.append(MultinomialNB())
clfs.append(MLPClassifier())
clfs.append(GradientBoostingClassifier())



# Test models before parameter tuning
best_model = ""
best_acc = 0
best_score = 0
print("Test for different models:................................................")
for classifier in clfs:
    pipeline.set_params(clf = classifier)
    
    pipeline.fit(twenty_train.data, twenty_train.target)
    predicted = pipeline.predict(docs_test)
    accuracy = np.mean(predicted == twenty_test.target)
    scores = cross_validate(pipeline,twenty_train.data, twenty_train.target)
    model_name = type(classifier).__name__
    if(accuracy > best_acc):
        best_acc = accuracy
        best_score = np.mean(scores['test_score'])
        best_model = model_name
    print("-----------------------------------------------------------------")
    print(model_name)
    print(model_name+" accuracy: ", accuracy)
    for key, values in scores.items():
            print(model_name+" "+ key,' mean ', values.mean())
            print(model_name+" " + key,' std ', values.std())
print("-----------------------------------------------------------------")
print("Best Model is " + best_model)
print("Best Accuracy: ", best_acc)
print("Best score mean: ", best_score)


# find best parameters
best_model = ""
best_acc = 0
best_sc = 0
print("Tuning hyperparameters for the models:..............................................")
for classifier in clfs:
    pipeline.set_params(clf=classifier)
    param_name = ""
    if (isinstance(classifier, LinearSVC)):
        cv_grid = GridSearchCV(pipeline, param_grid={
            'clf__penalty': ['l2'],
            'clf__loss': ['squared_hinge'],
            'clf__dual': [False],
            'clf__C':np.linspace(0.1,1,20),#0.7?
            'clf__random_state': [42]
        }, cv=10)
        param_name = 'clf__C'
    elif (isinstance(classifier, LogisticRegression)):
        cv_grid = GridSearchCV(pipeline, param_grid={
            'clf__penalty': ['l2'],
            'clf__dual': [False],
            'clf__C': [0.01, 0.1, 1, 10, 100, 1000], #1000
            'clf__solver': ['liblinear'],
            'clf__max_iter':[1000000],
            'clf__random_state': [42]
        }, cv=10)
        param_name = 'clf__C'
        
    elif isinstance(classifier, AdaBoostClassifier):
        cv_grid = GridSearchCV(pipeline, param_grid={
            'clf__learning_rate': np.linspace(0.1,1,20),#0.5
            'clf__random_state': [42],
            'clf__n_estimators': [50] # try it after finding best lr
        }, cv=10)
        param_name = 'clf__learning_rate'
    elif isinstance(classifier, RandomForestClassifier):
        cv_grid = GridSearchCV(pipeline, param_grid={
            'clf__n_estimators': [50],
            'clf__criterion': ['gini'],
            'clf__max_features': ['auto', 'log2'],
            'clf__max_depth': [None],
            'clf__max_leaf_nodes': [None],
            'clf__random_state': [42]
        }, cv=10)
        param_name = 'clf__max_features'
    elif isinstance(classifier, DecisionTreeClassifier):
        cv_grid = GridSearchCV(pipeline, param_grid={
            'clf__criterion': ['gini'],
            'clf__max_depth': [10, 50, 100, 200, 1000],
            'clf__max_leaf_nodes': [None],
            'clf__random_state': [42]
        }, cv=10)
        param_name = 'clf__max_depth'
    else:
        continue
    
    # Train the model with different hyperparameters
    cv_grid.fit(twenty_train.data, twenty_train.target)
    best_par = cv_grid.best_params_
    best_estimator = cv_grid.best_estimator_
    best_score = cv_grid.best_score_
    model_name = type(classifier).__name__
    
    # Print the best hyperparameters found
    print("-----------------------------------------------------------------")
    print(model_name)
    print(model_name + " best parameter: " + str(best_par))
    print(model_name + " best estimator: " + str(best_estimator.steps[2]))
    print(model_name + " best CV score: " + str(best_score))
    y_predict = cv_grid.predict(docs_test)
    accuracy = accuracy_score(twenty_test.target, y_predict)
    print('Accuracy of the best ' + model_name + ' after CV is %.6f%%' % (accuracy * 100))
    if (accuracy > best_acc):
        best_acc = accuracy
        best_sc = best_score
        best_model = model_name




    # get results
    cv_results = cv_grid.cv_results_
    scores_df = pd.DataFrame(cv_results).sort_values(by='rank_test_score')
    means = scores_df['mean_test_score']
    stds = scores_df['std_test_score']
    best_row = scores_df.iloc[0, :]
    params = scores_df['param_' + param_name]
    best_mean = best_row['mean_test_score']
    best_stdev = best_row['std_test_score']
    best_param = best_row['param_' + param_name]

    # plot results
    plt.figure(figsize=(8, 8))
    plt.scatter(params, means)
    plt.axhline(y=best_mean + best_stdev, color='red')
    plt.axhline(y=best_mean - best_stdev, color='red')
    plt.plot(best_param, best_mean, 'or')

    plt.title(param_name + " vs Score\nBest Score {:0.5f}".format(best_score))
    plt.xlabel(param_name)
    plt.ylabel('Score')
    plt.show()


# Print best model after parameter tuning
print("-----------------------------------------------------------------")
print("After Tuning hyperparameters the best Model is " + best_model)
print("Best Accuracy: ", best_acc)
print("Best score mean: ", best_sc)

plt.show()